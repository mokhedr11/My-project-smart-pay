package com.smartpay.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101828)
private val Navy = Color(0xFF142B4A)
private val Blue = Color(0xFF3978E8)
private val Muted = Color(0xFF667085)
private val Canvas = Color(0xFFF5F7FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartPayApp() }
    }
}

private enum class Tab(val label: String) {
    HOME("Home"), CARDS("Cards"), ACTIVITY("Activity"), SETTINGS("Settings")
}

private data class BankCard(val bank: String, val holder: String, val last4: String, val accent: Color)
private data class Transaction(val merchant: String, val detail: String, val amount: String, val positive: Boolean)

@Composable
fun SmartPayApp() {
    var selectedTab by remember { mutableStateOf(Tab.HOME) }
    var selectedCard by remember { mutableIntStateOf(0) }
    val cards = remember {
        listOf(
            BankCard("CIB", "Demo User", "4821", Color(0xFF1D4778)),
            BankCard("NBE", "Demo User", "0936", Color(0xFF176B50)),
            BankCard("Bank Misr", "Demo User", "7710", Color(0xFF8B2635))
        )
    }
    val transactions = remember {
        listOf(
            Transaction("Coffee Corner", "Today · 10:42 AM · CIB", "EGP 85.00", false),
            Transaction("Online Store", "Yesterday · 7:18 PM · NBE", "EGP 420.00", false),
            Transaction("Refund", "Nov 20 · Bank Misr", "+ EGP 120.00", true)
        )
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            background = Canvas,
            surface = Color.White,
            onBackground = Ink,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Canvas,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    Tab.values().forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = {
                                Icon(
                                    when (tab) {
                                        Tab.HOME -> Icons.Default.Home
                                        Tab.CARDS -> Icons.Default.CreditCard
                                        Tab.ACTIVITY -> Icons.Default.ReceiptLong
                                        Tab.SETTINGS -> Icons.Default.Settings
                                    }, contentDescription = tab.label
                                )
                            },
                            label = { Text(tab.label, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                Tab.HOME -> HomeScreen(
                    cards, selectedCard, { selectedCard = it }, transactions,
                    onCards = { selectedTab = Tab.CARDS },
                    modifier = Modifier.padding(padding)
                )
                Tab.CARDS -> CardsScreen(cards, modifier = Modifier.padding(padding))
                Tab.ACTIVITY -> ActivityScreen(transactions, modifier = Modifier.padding(padding))
                Tab.SETTINGS -> SettingsScreen(modifier = Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun HomeScreen(
    cards: List<BankCard>,
    selectedCard: Int,
    onSelectCard: (Int) -> Unit,
    transactions: List<Transaction>,
    onCards: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("SMARTPAY", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Your wallet, simplified.", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Surface(shape = RoundedCornerShape(50), color = Color.White) {
                    Icon(Icons.Default.NotificationsNone, null, modifier = Modifier.padding(12.dp), tint = Ink)
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Preferred card", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text("Manage", color = Blue, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { onCards() })
                }
                PaymentCard(cards[selectedCard])
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    cards.forEachIndexed { index, card ->
                        FilterChip(
                            selected = selectedCard == index,
                            onClick = { onSelectCard(index) },
                            label = { Text(card.bank) }
                        )
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                InfoTile("NFC status", "Check device", Icons.Default.Nfc, Modifier.weight(1f))
                InfoTile("Security", "Device protected", Icons.Default.Fingerprint, Modifier.weight(1f))
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Ready to pay?", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Choose your bank's approved payment app or default wallet to complete a contactless payment.",
                    color = Muted, fontSize = 13.sp, lineHeight = 19.sp
                )
                Button(
                    onClick = { },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Nfc, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Open payment options")
                }
                Text(
                    "Demo only · SmartPay does not process payments in this version.",
                    color = Muted, fontSize = 11.sp
                )
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Recent activity", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("See all", color = Blue, modifier = Modifier.clickable { })
            }
        }
        items(transactions.take(3)) { TransactionRow(it) }
    }
}

@Composable
private fun PaymentCard(card: BankCard) {
    Box(
        modifier = Modifier.fillMaxWidth().height(190.dp)
            .background(Brush.linearGradient(listOf(card.accent, Color(0xFF101828))), RoundedCornerShape(22.dp))
            .padding(20.dp)
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("SMARTPAY WALLET", color = Color.White.copy(alpha = .72f), fontSize = 10.sp, letterSpacing = 1.5.sp)
                    Text(card.bank, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Icon(Icons.Default.Wifi, null, tint = Color.White.copy(alpha = .85f))
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("••••  ••••  ••••  ${card.last4}", color = Color.White, fontSize = 19.sp, letterSpacing = 1.5.sp)
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text(card.holder.uppercase(), color = Color.White.copy(alpha = .8f), fontSize = 10.sp)
                    Text("DEMO CARD", color = Color.White.copy(alpha = .7f), fontSize = 9.sp)
                }
            }
        }
    }
}

@Composable
private fun InfoTile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = Color.White, shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(25.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Text(subtitle, color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun CardsScreen(cards: List<BankCard>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("My cards", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Demo cards only. No real card numbers are stored.", color = Muted, fontSize = 13.sp)
        cards.forEach { PaymentCard(it) }
        OutlinedButton(onClick = { }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text("Connect a bank (coming soon)")
        }
    }
}

@Composable
private fun ActivityScreen(transactions: List<Transaction>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Activity", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Your recent payment activity", color = Muted)
        transactions.forEach { TransactionRow(it) }
        Text("Automatic bank notifications will be added in a later phase, with your permission.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun TransactionRow(transaction: Transaction) {
    Surface(color = Color.White, shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Canvas, shape = RoundedCornerShape(12.dp)) {
                Icon(if (transaction.positive) Icons.Default.SouthWest else Icons.Default.NorthEast, null, tint = if (transaction.positive) Color(0xFF16845B) else Navy, modifier = Modifier.padding(11.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(transaction.merchant, fontWeight = FontWeight.SemiBold)
                Text(transaction.detail, color = Muted, fontSize = 11.sp)
            }
            Text(transaction.amount, fontWeight = FontWeight.SemiBold, color = if (transaction.positive) Color(0xFF16845B) else Ink, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SettingsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        SettingRow(Icons.Default.Fingerprint, "Biometric unlock", "Use device biometrics where supported")
        SettingRow(Icons.Default.Security, "Privacy & security", "Your financial credentials stay with your bank")
        SettingRow(Icons.Default.Nfc, "Contactless payments", "Managed by Android and your payment provider")
        SettingRow(Icons.Default.Info, "About SmartPay", "Version 0.1.0 · Prototype")
    }
}

@Composable
private fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Surface(color = Color.White, shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 11.sp)
            }
        }
    }
}
