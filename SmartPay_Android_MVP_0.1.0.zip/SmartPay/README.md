# SmartPay Android MVP — 0.1.0

A Kotlin + Jetpack Compose UI prototype for a unified payment experience.

## Included
- Home dashboard
- Demo bank cards (fictional last-four digits)
- Recent activity with sample transactions
- Cards, Activity, and Settings screens
- NFC and biometric capability placeholders

## Important scope and safety
This build is a UI prototype. It does not initiate payments, emulate bank cards, store PAN/CVV/PIN, or access bank credentials.
Real contactless payments require an approved payment provider/bank integration and the Android default payment-app / HCE requirements where applicable. SmartPay cannot independently force a second tap to succeed or change another bank app's NFC behavior.

## Open
1. Unzip the project.
2. Open the `SmartPay` folder in Android Studio.
3. Let Gradle sync.
4. Run on an Android device or emulator (API 26+).

## Next implementation milestones
1. Detect NFC availability and show actual adapter state.
2. Add AndroidX BiometricPrompt for local app unlock (not bank authorization).
3. Add an opt-in notification parser for transaction alerts; parse only sender-approved/known formats and let the user correct entries.
4. Integrate with banks only through documented partner APIs/SDKs.
5. Evaluate default payment app / HCE eligibility with a payment provider. Do not implement payment emulation without issuer/network approval.
